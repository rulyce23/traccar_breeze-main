<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class DeviceController extends Controller
{
    protected $traccarApiUrl;
    protected $username;
    protected $password;

    public function __construct()
    {
        $this->traccarApiUrl = env('TRACCAR_API_URL');
        $this->username = env('TRACCAR_USERNAME');
        $this->password = env('TRACCAR_PASSWORD');
    }
    public function create()
    {
        return view('master.device.create');
    }
    public function store(Request $request)
    {
        $formData = [
            'name' => $request->input('name'),
            'uniqueId' => $request->input('uniqueId'),
            'phone' => $request->input('phone')
        ];
        $response = Http::withBasicAuth($this->username, $this->password)
            ->post($this->traccarApiUrl . '/devices', $formData);

        $data = $response->json();
        return response()->json($data);
    }
}
